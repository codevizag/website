<?php
//You can create your very own admin.php dashboard icon here
//Feel free to delete this file if you don't need it.

//here is an example.
?>
<a href="<?=$us_url_root?>users/admin.php"><div class="col-md-1 col-sm-3 col-sm-6 col-centered">
  <div class="panel panel-default">
    <i class="fa fa-qq fa-2x"></i><br>Discord Login<br>Icon</li>
  </div>
</div></a>
